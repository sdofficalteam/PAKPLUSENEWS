import { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { fetchTopHeadlines, fetchEverything, Article } from '../lib/api';
import NewsCard from '../components/NewsCard';
import { NewsCardSkeleton } from '../components/Skeleton';
import { Filter } from 'lucide-react';

export default function Category() {
  const { id } = useParams<{ id: string }>();
  const [articles, setArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const location = useLocation();

  const title = (id?.charAt(0).toUpperCase() || '') + (id?.slice(1) || '');

  const loadData = async (pageNum: number, reset = false) => {
    try {
      if (reset) {
        setLoading(true);
        setPage(1);
      } else {
        setLoadingMore(true);
      }

      let res;
      if (id === 'latest') {
        res = await fetchTopHeadlines(undefined, 'us', pageNum);
      } else if (id === 'world' || id === 'pakistan') {
         res = await fetchEverything(id === 'world' ? 'world news' : 'Pakistan', pageNum);
      } else {
        res = await fetchTopHeadlines(id, 'us', pageNum);
      }
      
      if (res.articles.length < 10) {
        setHasMore(false);
      } else {
        setHasMore(true);
      }

      setArticles(prev => reset ? res.articles : [...prev, ...res.articles]);
    } catch (err) {
      console.error(err);
      setHasMore(false);
    } finally {
      setLoading(false);
      setLoadingMore(false);
    }
  };

  useEffect(() => {
    loadData(1, true);
  }, [id]);

  const observer = useRef<IntersectionObserver | null>(null);
  const lastElementRef = useCallback((node: HTMLDivElement | null) => {
    if (loading || loadingMore) return;
    if (observer.current) observer.current.disconnect();
    observer.current = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting && hasMore) {
        setPage(prev => {
          const next = prev + 1;
          loadData(next, false);
          return next;
        });
      }
    });
    if (node) observer.current.observe(node);
  }, [loading, loadingMore, hasMore]);

  return (
    <div className="max-w-[1400px] mx-auto px-4 md:px-8 py-8 md:py-12 min-h-screen">
      <Helmet>
        <title>{title} News | PakPulse</title>
      </Helmet>

      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between border-b-2 border-brand-red pb-4 mb-8 gap-4">
         <div>
            <h1 className="text-3xl md:text-4xl font-black text-brand-blue dark:text-white uppercase tracking-tight relative mb-1">
               {title} <span className="text-brand-red">News</span>
            </h1>
            <p className="text-gray-500 dark:text-gray-400 font-medium">Latest and breaking updates regarding {title.toLowerCase()}.</p>
         </div>
         <div className="flex items-center gap-2 text-sm font-bold text-gray-500 dark:text-gray-400 bg-white dark:bg-slate-800 px-4 py-2 rounded-lg border border-gray-200 dark:border-slate-700">
            <Filter className="w-4 h-4" /> Filter / Sort
         </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 md:gap-8">
        {loading ? (
          Array(12).fill(0).map((_, i) => <NewsCardSkeleton key={i} />)
        ) : articles.length > 0 ? (
          articles.map((article, index) => {
            if (articles.length === index + 1) {
              return (
                <div ref={lastElementRef} key={index} className={index === 0 ? "lg:col-span-2" : ""}>
                   <NewsCard article={article} featured={index === 0} />
                </div>
              );
            }
            return (
               <div key={index} className={index === 0 ? "lg:col-span-2" : ""}>
                  <NewsCard article={article} featured={index === 0} />
               </div>
            );
          })
        ) : (
          <div className="col-span-full text-center py-20 text-gray-500">
            No articles found for this category at the moment.
          </div>
        )}
      </div>

      {loadingMore && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 md:gap-8 mt-8">
          {Array(4).fill(0).map((_, i) => <NewsCardSkeleton key={`more-${i}`} />)}
        </div>
      )}
      
      {!hasMore && articles.length > 0 && !loading && (
        <p className="text-center text-gray-500 font-medium mt-12 py-8 border-t border-gray-200 dark:border-slate-800">
           You have reached the end of the feed.
        </p>
      )}
    </div>
  );
}
