import { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { format } from 'date-fns';
import { Link } from 'react-router-dom';
import { fetchTopHeadlines, fetchEverything, Article } from '../lib/api';
import NewsCard from '../components/NewsCard';
import Skeleton, { NewsCardSkeleton } from '../components/Skeleton';
import { Flame, RefreshCcw, TrendingUp } from 'lucide-react';

export default function Home() {
  const [heroArticles, setHeroArticles] = useState<Article[]>([]);
  const [trendingArticles, setTrendingArticles] = useState<Article[]>([]);
  const [pakistanNews, setPakistanNews] = useState<Article[]>([]);
  const [techNews, setTechNews] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const loadData = async () => {
    try {
      setRefreshing(true);
      const [topRes, trendingRes, pkRes, techRes] = await Promise.all([
        fetchTopHeadlines('general', 'us'),
        fetchEverything('trending news OR viral', 1),
        fetchEverything('Pakistan', 1),
        fetchTopHeadlines('technology')
      ]);
      setHeroArticles(topRes.articles.slice(0, 5));
      setTrendingArticles(trendingRes.articles.slice(0, 4));
      setPakistanNews(pkRes.articles.slice(0, 6));
      setTechNews(techRes.articles.slice(0, 4));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadData();
    // Auto refresh every 30 mins
    const interval = setInterval(loadData, 30 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  const today = format(new Date(), 'EEEE, MMMM do, yyyy');

  return (
    <div className="w-full">
      <Helmet>
        <title>PakPulse News | Live Breaking News & Updates</title>
      </Helmet>

      <div className="max-w-[1400px] mx-auto px-4 md:px-6 py-6 flex flex-col gap-6">
        
        {/* Section: Main Headlines & Sidebar */}
        <section className="grid grid-cols-1 lg:grid-cols-12 gap-4 md:gap-6">
           
           {/* Main Hero Feed (Left/8 cols) */}
           <div className="lg:col-span-8 flex flex-col gap-4 md:gap-6">
              <div className="flex items-center justify-between pb-2 border-b-2 border-brand-red dark:border-brand-red-dark">
                 <h1 className="text-2xl font-black text-brand-blue dark:text-white uppercase tracking-tight flex items-center gap-2">
                   Top Headlines
                 </h1>
                 <button onClick={loadData} disabled={refreshing} className="p-2 text-gray-500 hover:text-brand-blue dark:hover:text-white transition-colors" title="Refresh Feed">
                   <RefreshCcw className={`w-5 h-5 ${refreshing ? 'animate-spin' : ''}`} />
                 </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                 {loading ? (
                    <>
                       <NewsCardSkeleton featured className="md:col-span-2" />
                       <NewsCardSkeleton />
                       <NewsCardSkeleton />
                    </>
                 ) : (
                    <>
                       {heroArticles[0] && <NewsCard article={heroArticles[0]} featured />}
                       <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-6 md:col-span-2">
                         {heroArticles.slice(1, 3).map((a, i) => (
                           <NewsCard key={i} article={a} />
                         ))}
                       </div>
                    </>
                 )}
              </div>
           </div>

           {/* Trending Sidebar (Right/4 cols) */}
           <aside className="lg:col-span-4 flex flex-col gap-4 md:gap-6">
              <div className="bg-white dark:bg-slate-900 rounded-xl border border-gray-100 dark:border-slate-800 p-5 shadow-sm flex-1">
                 <div className="flex justify-between items-center mb-4">
                   <h3 className="font-black uppercase text-sm tracking-widest border-b-2 border-brand-red pb-1 dark:text-white flex items-center gap-1.5"><TrendingUp className="w-4 h-4 text-brand-red" /> Trending Now</h3>
                   <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Live Updates</span>
                 </div>
                 <div className="space-y-5">
                    {loading ? (
                       Array(4).fill(0).map((_, i) => <Skeleton key={i} className="h-16 w-full" />)
                    ) : (
                       trendingArticles.map((a, i) => (
                          <a href={a.url} target="_blank" rel="noopener noreferrer" key={i} className="flex gap-4 group cursor-pointer">
                             <span className="text-3xl font-black text-gray-200 dark:text-slate-700 group-hover:text-brand-red transition-colors leading-none">0{i + 1}</span>
                             <div className="border-b border-gray-100 dark:border-slate-800 pb-3 flex-1 group-hover:border-brand-red/30 transition-colors">
                                <h4 className="text-xs font-bold leading-normal dark:text-gray-200 line-clamp-2">{a.title}</h4>
                                <span className="text-[10px] text-brand-blue-light dark:text-gray-400 mt-1 block uppercase tracking-wider font-bold">{a.source.name}</span>
                             </div>
                          </a>
                       ))
                    )}
                 </div>
              </div>

              {/* Sidebar Subscription Widget from Bento Grid */}
              <div className="bg-brand-blue rounded-xl p-5 text-white flex flex-col justify-between overflow-hidden relative shadow-sm">
                 <div className="absolute top-0 right-0 w-32 h-32 bg-brand-red rounded-bl-full opacity-20 pointer-events-none"></div>
                 <h3 className="text-lg font-black mb-2 relative z-10">Join Pulse Insider</h3>
                 <p className="text-xs text-white/70 mb-4 relative z-10">Get exclusive morning briefings delivered to your inbox.</p>
                 {subscribed ? (
                    <div className="text-xs font-bold text-emerald-400 relative z-10 bg-white/10 px-3 py-2 rounded">
                       Thanks! You've been subscribed.
                    </div>
                 ) : (
                    <form onSubmit={(e) => { e.preventDefault(); if (email) setSubscribed(true); }} className="space-y-2 relative z-10 flex flex-col">
                       <input type="email" value={email} onChange={e => setEmail(e.target.value)} required placeholder="your@email.com" className="w-full bg-white/10 border border-white/20 rounded px-3 py-2 text-xs text-white placeholder:text-white/40 focus:outline-none focus:border-brand-red" />
                       <button type="submit" className="w-full bg-brand-red text-white py-2 rounded text-xs font-bold uppercase hover:bg-brand-red-dark transition-colors">Subscribe Now</button>
                    </form>
                 )}
              </div>
           </aside>
        </section>

        {/* Section: Pakistan Focus */}
        <section className="flex flex-col gap-6">
           <div className="flex items-center justify-between pb-4 border-b-[3px] border-emerald-600">
              <h2 className="text-2xl font-heading font-black text-brand-blue dark:text-white uppercase tracking-tight flex items-center gap-3">
                 Pakistan News
              </h2>
              <Link to="/category/pakistan" className="text-sm font-bold text-brand-blue dark:text-white hover:text-brand-red dark:hover:text-brand-red group flex items-center gap-1 transition-colors">
                 View All <span className="text-emerald-600 text-lg leading-none group-hover:translate-x-1 transition-transform">›</span>
              </Link>
           </div>
           
           <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {loading ? (
                 Array(4).fill(0).map((_, i) => <NewsCardSkeleton key={i} />)
              ) : pakistanNews.length > 0 ? (
                 pakistanNews.slice(0,4).map((a, i) => (
                    <NewsCard key={i} article={a} />
                 ))
              ) : (
                 <p className="col-span-4 text-center text-gray-500 py-10">No recent articles found.</p>
              )}
           </div>
        </section>

        {/* Section: Tech & Sci Focus */}
        <section className="flex flex-col gap-6">
           <div className="flex items-center justify-between pb-4 border-b-[3px] border-indigo-600">
              <h2 className="text-2xl font-heading font-black text-brand-blue dark:text-white uppercase tracking-tight flex items-center gap-3">
                 Tech & Science
              </h2>
           </div>
           
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {loading ? (
                 Array(4).fill(0).map((_, i) => <NewsCardSkeleton key={i} />)
              ) : techNews.length > 0 ? (
                 techNews.map((a, i) => (
                    <NewsCard key={i} article={a} />
                 ))
              ) : (
                 <p className="col-span-4 text-center text-gray-500 py-10">No tech articles found.</p>
              )}
           </div>
        </section>
        
      </div>
    </div>
  );
}
