import { Helmet } from 'react-helmet-async';
import { useStore } from '../lib/store';
import NewsCard from '../components/NewsCard';
import { BookmarkMinus } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Bookmarks() {
  const savedArticles = useStore(state => state.savedArticles);

  return (
    <div className="max-w-[1400px] mx-auto px-4 md:px-8 py-8 md:py-12 min-h-screen">
      <Helmet>
        <title>Saved Articles | PakPulse</title>
      </Helmet>

      <div className="mb-10 border-b-2 border-brand-blue pb-4">
        <h1 className="text-3xl md:text-4xl font-heading font-black text-brand-blue dark:text-white uppercase tracking-tight flex items-center gap-3">
          Saved <span className="text-brand-red">Articles</span>
        </h1>
        <p className="text-gray-500 dark:text-gray-400 mt-2 font-medium">Read your bookmarked articles offline anytime.</p>
      </div>

      {savedArticles.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 md:gap-8">
          {[...savedArticles].reverse().map((article, index) => (
            <NewsCard key={index} article={article} />
          ))}
        </div>
      ) : (
        <div className="text-center py-32 bg-white dark:bg-slate-900 rounded-2xl border border-gray-100 dark:border-slate-800 shadow-sm max-w-3xl mx-auto">
          <div className="w-24 h-24 bg-brand-gray dark:bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-6 text-gray-400">
            <BookmarkMinus className="w-12 h-12" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">No Saved Articles yet</h2>
          <p className="text-gray-500 dark:text-gray-400 mb-8 max-w-sm mx-auto">
             Keep track of important news by clicking the bookmark icon on any article you want to read later.
          </p>
          <Link 
            to="/" 
            className="inline-flex py-3 px-8 bg-brand-red hover:bg-brand-red-dark transition-colors rounded-lg font-bold text-white uppercase tracking-wider text-sm shadow-md"
          >
            Explore News
          </Link>
        </div>
      )}
    </div>
  );
}
