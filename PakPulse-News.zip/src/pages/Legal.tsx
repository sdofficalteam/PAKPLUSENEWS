import { useParams } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { motion } from 'motion/react';

interface LegalProps {
  page: string;
}

const getContent = (pageKey: string) => {
  const contentMap: Record<string, { title: string, content: string }> = {
    'about': {
      title: 'About Us',
      content: `
        <h2>Who We Are</h2>
        <p>Welcome to <strong>PakPulse News Network</strong>, your premier source for comprehensive, accurate, and up-to-the-minute news coverage. Owned and operated by Sajjad Ahmed in Pakistan, we are dedicated to bringing you the stories that matter most, from local community issues to significant global events.</p>
        <h2>Our Mission</h2>
        <p>Our mission is to deliver unbiased, high-quality journalism that informs, engages, and empowers our readers. In an era of rampant misinformation, PakPulse stands as a beacon of truth and reliability.</p>
        <h2>Editorial Standards</h2>
        <p>We adhere to strict editorial guidelines ensuring our content is accurate, fair, and impartial. We believe in the power of responsible journalism to foster a more informed society.</p>
      `
    },
    'contact': {
      title: 'Contact Us',
      content: `
        <h2>Get in Touch</h2>
        <p>We value feedback from our readers. Whether you have a news tip, a question, or a concern, we want to hear from you.</p>
        <ul>
           <li><strong>Owner:</strong> Sajjad Ahmed</li>
           <li><strong>Email:</strong> <a href="mailto:sdofficalteam@gmail.com">sdofficalteam@gmail.com</a></li>
           <li><strong>Country:</strong> Pakistan</li>
        </ul>
        <br />
        <div class="bg-gray-50 dark:bg-slate-800 p-6 rounded-lg border border-gray-200 dark:border-slate-700">
           <p>For urgent press inquiries or tip-offs, please use the email provided above with the subject line "URGENT NEWS TIP". All communications are kept strictly confidential.</p>
        </div>
      `
    },
    'privacy': {
       title: 'Privacy Policy',
       content: `
         <p>Last Updated: ${new Date().toLocaleDateString()}</p>
         <p>At PakPulse News, accessible from our public web portal, one of our main priorities is the privacy of our visitors. This Privacy Policy document contains types of information that is collected and recorded by PakPulse News and how we use it.</p>
         <h2>Information We Collect</h2>
         <p>The personal information that you are asked to provide, and the reasons why you are asked to provide it, will be made clear to you at the point we ask you to provide your personal information. If you contact us directly, we may receive additional information about you such as your name, email address, phone number, the contents of the message and/or attachments you may send us.</p>
         <h2>Local Storage (Bookmarks)</h2>
         <p>We use your browser's Local Storage to save articles you bookmark. This data remains entirely on your device and is not transmitted to our servers.</p>
       `
    },
    'terms': {
       title: 'Terms & Conditions',
       content: `
          <p>These terms and conditions outline the rules and regulations for the use of PakPulse News Network's Website.</p>
          <p>By accessing this website we assume you accept these terms and conditions. Do not continue to use PakPulse News if you do not agree to take all of the terms and conditions stated on this page.</p>
          <h2>License</h2>
          <p>Unless otherwise stated, PakPulse News and/or its licensors own the intellectual property rights for all material on PakPulse News. All intellectual property rights are reserved.</p>
       `
    },
    'disclaimer': {
       title: 'Disclaimer',
       content: `
          <p>The information provided by PakPulse News on our website is for general informational purposes only. While we strive to present accurate and up-to-date information, we make no representations or warranties of any kind, express or implied, about the completeness, accuracy, reliability, suitability, or availability with respect to the website or the information, products, services, or related graphics contained on the website for any purpose.</p>
       `
    },
    'cookie-policy': {
       title: 'Cookie Policy',
       content: `
          <p>This is the Cookie Policy for PakPulse News.</p>
          <h2>What Are Cookies</h2>
          <p>As is common practice with almost all professional websites, this site uses cookies, which are tiny files that are downloaded to your computer, to improve your experience. Currently, this site primarily utilizes Local Storage for saving preferences (like Dark Mode) and bookmarked articles to protect your privacy and reduce server tracking.</p>
       `
    },
    'dmca': {
       title: 'DMCA Policy',
       content: `
          <p>PakPulse News respects the intellectual property rights of others and expects its users to do the same. In accordance with the Digital Millennium Copyright Act of 1998, the text of which may be found on the U.S. Copyright Office website.</p>
          <p>If you believe that your work has been copied in a way that constitutes copyright infringement, please provide our Copyright Agent with the following information via email:</p>
          <ul>
             <li>A physical or electronic signature of the copyright owner</li>
             <li>Identification of the copyrighted work claimed to have been infringed</li>
          </ul>
       `
    },
    'editorial-policy': {
       title: 'Editorial Policy',
       content: `
          <p>Our editorial decisions are driven by news value, public interest, and a commitment to truth. Our journalists and editors work independently and are free from commercial or political interference.</p>
          <h2>Standards of Accuracy</h2>
          <p>We verify information from multiple reliable sources before publication. Hearsay and unverified rumors are clearly labeled or avoided entirely.</p>
       `
    },
    'corrections': {
       title: 'Corrections Policy',
       content: `
          <p>PakPulse News is committed to transparency and accuracy. If an error is published, we will acknowledge it and correct it as quickly as possible. We maintain a clear record of corrections at the end of the affected article.</p>
          <p>To request a correction, please contact our editorial team at sdofficalteam@gmail.com with the subject line "Correction Request".</p>
       `
    },
    'fact-checking': {
       title: 'Fact Checking Policy',
       content: `
          <p>We believe fact-checking is the cornerstone of credible journalism. Our writers and editors cross-reference claims, official statements, and data points against primary sources of trust.</p>
          <p>We differentiate clearly between factual reporting, analysis, and opinion pieces to ensure our audience is never misled.</p>
       `
    }
  };
  
  return contentMap[pageKey] || { title: 'Legal', content: '<p>Content not found.</p>' };
};

export default function Legal({ page }: LegalProps) {
  if (page === 'contact') {
    return (
      <div className="max-w-[1400px] mx-auto px-4 py-8 md:py-12 min-h-[70vh]">
        <Helmet>
          <title>Contact Us | PakPulse News</title>
        </Helmet>
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-slate-900 border border-gray-100 dark:border-slate-800 shadow-sm rounded-2xl overflow-hidden mb-12"
        >
           <div className="bg-brand-blue text-white px-8 md:px-12 py-10 md:py-16 text-center border-b-4 border-brand-red relative overflow-hidden">
              <div className="absolute inset-0 bg-[linear-gradient(45deg,transparent_25%,rgba(255,255,255,0.05)_50%,transparent_75%,transparent_100%)] bg-[length:250px_250px] animate-[pulse_3s_linear_infinite]"></div>
              <h1 className="text-4xl md:text-5xl font-heading font-black uppercase tracking-widest relative z-10">Contact Us</h1>
              <p className="mt-4 text-brand-blue-light text-blue-200 uppercase tracking-widest text-sm font-bold relative z-10">PakPulse News Network</p>
           </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 pb-12">
          {/* Contact Form Area */}
          <motion.div 
             initial={{ opacity: 0, x: -20 }}
             animate={{ opacity: 1, x: 0 }}
             className="bg-white dark:bg-slate-900 p-8 md:p-10 rounded-2xl border border-gray-100 dark:border-slate-800 shadow-sm relative z-10"
          >
            <div className="typography-prose mb-8 dark:text-gray-300">
              <h2 className="text-3xl font-black mb-4 text-brand-blue dark:text-white tracking-tight">Get in Touch</h2>
              <p className="mb-6 text-gray-600 dark:text-gray-400">We value feedback from our readers. Whether you have a news tip, a question, or a concern, we want to hear from you.</p>
              <ul className="space-y-3 bg-gray-50 dark:bg-slate-800/50 p-6 rounded-xl border border-gray-100 dark:border-slate-800">
                 <li className="flex items-center gap-3"><strong className="text-brand-blue dark:text-gray-200 w-20 text-sm uppercase tracking-wider">Owner:</strong> <span className="text-gray-600 dark:text-gray-400 font-medium">Sajjad Ahmed</span></li>
                 <li className="flex items-center gap-3"><strong className="text-brand-blue dark:text-gray-200 w-20 text-sm uppercase tracking-wider">Email:</strong> <a href="mailto:sdofficalteam@gmail.com" className="text-brand-red hover:underline font-bold">sdofficalteam@gmail.com</a></li>
                 <li className="flex items-center gap-3"><strong className="text-brand-blue dark:text-gray-200 w-20 text-sm uppercase tracking-wider">Country:</strong> <span className="text-gray-600 dark:text-gray-400 font-medium">Pakistan</span></li>
              </ul>
            </div>

            <form className="space-y-5" onSubmit={(e) => { e.preventDefault(); alert("Thanks for your message! We will get back to you soon."); }}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2">Your Name</label>
                  <input type="text" required className="w-full bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand-red/50 focus:border-brand-red dark:text-white transition-all" placeholder="John Doe" />
                </div>
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2">Your Email</label>
                  <input type="email" required className="w-full bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand-red/50 focus:border-brand-red dark:text-white transition-all" placeholder="john@example.com" />
                </div>
              </div>
              <div>
                 <label className="block text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2">Subject</label>
                 <input type="text" required className="w-full bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand-red/50 focus:border-brand-red dark:text-white transition-all" placeholder="News Tip / Inquiry" />
              </div>
              <div>
                 <label className="block text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2">Message</label>
                 <textarea rows={5} required className="w-full bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand-red/50 focus:border-brand-red dark:text-white transition-all resize-none" placeholder="Write your message here..."></textarea>
              </div>
              <button type="submit" className="w-full bg-brand-blue hover:bg-brand-blue-light dark:bg-brand-red dark:hover:bg-brand-red-dark text-white font-bold uppercase tracking-widest text-sm py-4 rounded-lg transition-all shadow-md hover:shadow-lg active:scale-[0.98]">
                Send Message
              </button>
            </form>
          </motion.div>

          {/* Agency CTA Section - Glowing Premium Card */}
          <motion.div 
             initial={{ opacity: 0, x: 20 }}
             animate={{ opacity: 1, x: 0 }}
             className="relative flex items-center justify-center p-4 sm:p-8 rounded-2xl h-full min-h-[400px]"
          >
            {/* Animated Gradient Background Glow */}
            <div className="absolute inset-0 bg-gradient-to-r from-brand-red via-purple-600 to-indigo-600 rounded-2xl opacity-30 blur-2xl animate-pulse"></div>
            
            {/* Premium Border container */}
            <div className="relative w-full h-full p-[2px] rounded-2xl bg-gradient-to-br from-brand-red via-purple-500 to-indigo-500 shadow-2xl hover:shadow-brand-red/40 transition-shadow duration-500 group/card flex flex-col">
               {/* Glassmorphism Inner Card */}
               <div className="bg-white/90 dark:bg-[#0B1F3A]/90 backdrop-blur-xl w-full h-full rounded-[14px] p-8 md:p-12 flex flex-col items-center justify-center text-center relative overflow-hidden group-hover/card:bg-white/80 dark:group-hover/card:bg-[#0B1F3A]/80 transition-colors flex-1">
                 
                 {/* Decorative background orbs */}
                 <div className="absolute top-0 right-0 -mr-20 -mt-20 w-64 h-64 bg-brand-red/10 rounded-full blur-3xl group-hover/card:bg-brand-red/20 transition-colors duration-700"></div>
                 <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl group-hover/card:bg-indigo-500/20 transition-colors duration-700"></div>

                 {/* Modern Icon/Graphic */}
                 <div className="w-20 h-20 bg-gradient-to-br from-brand-red to-purple-600 rounded-2xl text-white flex items-center justify-center mb-8 shadow-xl shadow-brand-red/20 transform group-hover/card:scale-110 group-hover/card:rotate-6 group-hover/card:-translate-y-2 transition-all duration-500">
                    <span className="text-4xl">🚀</span>
                 </div>
                 
                 <h3 className="text-3xl sm:text-4xl font-black text-brand-blue dark:text-white mb-4 tracking-tight relative z-10">Visit Our Agency</h3>
                 <p className="text-gray-600 dark:text-gray-300 mb-10 max-w-[320px] font-medium leading-relaxed relative z-10">
                    Partner with the creators of PakPulse for premium digital solutions. We specialize in modern SaaS development, high-end design, and digital growth strategy.
                 </p>
                 
                 <a 
                   href="https://digitaluqaab.agency"
                   target="_blank"
                   rel="noopener noreferrer"
                   className="relative inline-flex items-center justify-center px-8 py-4 font-bold text-white transition-all duration-300 bg-brand-blue dark:bg-slate-800 rounded-xl hover:bg-brand-red dark:hover:bg-brand-red hover:-translate-y-1 hover:shadow-xl hover:shadow-brand-red/30 overflow-hidden group/btn w-full sm:w-auto z-10 border border-white/10"
                 >
                   {/* Button highlight effect */}
                   <span className="absolute inset-0 w-full h-full bg-gradient-to-b from-white/10 to-transparent"></span>
                   
                   <span className="relative flex items-center gap-2 tracking-wide">
                     ✨ Visit Digital Uqaab Agency
                   </span>
                 </a>

               </div>
            </div>
          </motion.div>
        </div>

      </div>
    );
  }

  const { title, content } = getContent(page);

  return (
    <div className="max-w-[1000px] mx-auto px-4 py-12 md:py-16 min-h-[70vh]">
      <Helmet>
        <title>{title} | PakPulse News</title>
      </Helmet>
      
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white dark:bg-slate-900 border border-gray-100 dark:border-slate-800 shadow-xl rounded-2xl overflow-hidden"
      >
         <div className="bg-brand-blue text-white px-8 md:px-12 py-10 md:py-16 text-center border-b-4 border-brand-red">
            <h1 className="text-4xl md:text-5xl font-heading font-black uppercase tracking-widest">{title}</h1>
            <p className="mt-4 text-brand-blue-light text-blue-200 uppercase tracking-widest text-sm font-bold">PakPulse News Network</p>
         </div>
         <div 
           className="p-8 md:p-12 typography-prose text-gray-700 dark:text-gray-300 mx-auto"
           dangerouslySetInnerHTML={{ __html: content }} 
         />
      </motion.div>
    </div>
  );
}
