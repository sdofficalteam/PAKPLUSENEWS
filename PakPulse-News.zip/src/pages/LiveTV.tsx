import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { Play } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Using popular live channels available on YouTube as embeddable iframes.
// Note: Since real M3U8 streams or direct feeds require dedicated servers or licenses,
// and YouTube embeds can sometimes have restrictions if the broadcaster restricts embedding on certain domains, 
// using official YouTube live streams where possible, or representing the channels gracefully.
const LIVE_CHANNELS = [
  {
    country: 'Pakistan',
    name: 'Geo News',
    // Using a placeholder or an existing youtube live embed if available. 
    // Geo News YouTube channel ID often streams legally: UC1Eihs3D99_o2k2Kx2yJjgw
    // But since the actual video ID changes, we can use an embed search or a known 24/7 stream.
    // For demonstration, here's a well-known public stream technique:
    embedId: 'lB_A0fksW8w', 
    idType: 'video', 
    flag: '🇵🇰'
  },
  {
    country: 'United States',
    name: 'ABC News',
    embedId: 'w_Ma8oQLmSM', // Usually ABC News Live or similar
    idType: 'video',
    flag: '🇺🇸'
  },
  {
    country: 'United Kingdom',
    name: 'Sky News',
    embedId: '9Auq9mYxFEE', // Sky News Live
    idType: 'video',
    flag: '🇬🇧'
  },
  {
    country: 'India',
    name: 'Aaj Tak',
    embedId: 'Nq2wYlWFucg', // Aaj Tak Live
    idType: 'video',
    flag: '🇮🇳'
  },
  {
    country: 'Qatar',
    name: 'Al Jazeera',
    embedId: 'b_X3iOinT1A', // Al Jazeera English Live
    idType: 'video',
    flag: '🇶🇦'
  },
  {
    country: 'France',
    name: 'France 24',
    embedId: 'gCNeDWCI0vo', // France 24 Live
    idType: 'video',
    flag: '🇫🇷'
  },
  {
    country: 'Global',
    name: 'DW News',
    embedId: 'GE_SFJWwQlY', // DW News Live
    idType: 'video',
    flag: '🌐'
  }
];

export default function LiveTV() {
  const [activeChannel, setActiveChannel] = useState(LIVE_CHANNELS[0]);

  return (
    <div className="max-w-[1400px] mx-auto px-4 py-8 md:py-12 min-h-screen">
      <Helmet>
        <title>Live TV | PakPulse News</title>
      </Helmet>

      <div className="mb-8 border-b-2 border-brand-red pb-4 flex items-center justify-between">
        <h1 className="text-3xl md:text-4xl font-black text-brand-blue dark:text-white uppercase tracking-tight flex items-center gap-3">
           <span className="relative flex h-4 w-4 mr-1">
             <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-red opacity-75"></span>
             <span className="relative inline-flex rounded-full h-4 w-4 bg-brand-red"></span>
           </span>
           Live <span className="text-brand-red">TV</span>
        </h1>
        <p className="text-sm font-bold text-gray-500 uppercase tracking-widest hidden sm:block">Watch Global Coverage</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Main Player */}
        <div className="lg:col-span-8 flex flex-col gap-4">
           <div className="relative w-full overflow-hidden rounded-2xl bg-black shadow-lg shadow-brand-red/10 border border-gray-800" style={{ paddingTop: '56.25%' }}>
              <iframe
                title={activeChannel.name}
                className="absolute top-0 left-0 w-full h-full"
                src={`https://www.youtube.com/embed/${activeChannel.embedId}?autoplay=1&mute=0&live=1`}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              ></iframe>
           </div>
           
           <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-gray-100 dark:border-slate-800 shadow-sm flex items-center justify-between">
              <div>
                 <span className="text-[10px] font-black tracking-widest uppercase text-brand-red mb-1 block">Live Now</span>
                 <h2 className="text-2xl font-black text-brand-blue dark:text-white">{activeChannel.name}</h2>
                 <p className="text-gray-500 text-sm mt-1 flex items-center gap-2">
                    {activeChannel.flag} Streaming from {activeChannel.country}
                 </p>
              </div>
              <div className="bg-brand-red/10 text-brand-red px-4 py-2 rounded font-bold uppercase text-xs animate-pulse tracking-wide inline-flex items-center gap-2">
                 <span className="w-2 h-2 bg-brand-red rounded-full"></span> Live
              </div>
           </div>
        </div>

        {/* Channels List */}
        <div className="lg:col-span-4 flex flex-col gap-4">
           <h3 className="text-sm font-black uppercase tracking-widest text-gray-400 border-b border-gray-200 dark:border-slate-800 pb-2">Available Channels</h3>
           <div className="flex flex-col gap-3 overflow-y-auto max-h-[600px] pr-2 custom-scrollbar">
             <AnimatePresence>
               {LIVE_CHANNELS.map((channel, idx) => (
                 <motion.button
                   key={idx}
                   onClick={() => setActiveChannel(channel)}
                   whileHover={{ scale: 0.98 }}
                   className={`flex items-center gap-4 p-4 rounded-xl border text-left transition-all ${
                     activeChannel.name === channel.name 
                       ? 'bg-brand-blue dark:bg-brand-red border-brand-blue dark:border-brand-red text-white shadow-md' 
                       : 'bg-white dark:bg-slate-900 border-gray-100 dark:border-slate-800 hover:border-brand-red/50 text-gray-800 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-slate-800/50'
                   }`}
                 >
                   <div className={`w-12 h-12 flex items-center justify-center rounded-lg ${
                     activeChannel.name === channel.name ? 'bg-white/20' : 'bg-gray-100 dark:bg-slate-800'
                   }`}>
                     <Play className={`w-5 h-5 ${activeChannel.name === channel.name ? 'text-white' : 'text-brand-red'}`} />
                   </div>
                   <div className="flex-1">
                     <h4 className="font-bold">{channel.name}</h4>
                     <p className={`text-xs mt-1 ${activeChannel.name === channel.name ? 'text-white/80' : 'text-gray-500'}`}>
                       {channel.flag} {channel.country}
                     </p>
                   </div>
                   {activeChannel.name === channel.name && (
                     <div className="w-2 h-2 bg-brand-red md:bg-white rounded-full animate-ping"></div>
                   )}
                 </motion.button>
               ))}
             </AnimatePresence>
           </div>
        </div>

      </div>
    </div>
  );
}
