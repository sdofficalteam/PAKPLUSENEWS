import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { fetchEverything, Article } from '../lib/api';
import NewsCard from '../components/NewsCard';
import { NewsCardSkeleton } from '../components/Skeleton';
import { Search as SearchIcon } from 'lucide-react';

export default function Search() {
  const [searchParams, setSearchParams] = useSearchParams();
  const query = searchParams.get('q') || '';
  const [articles, setArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(false);
  const [localQuery, setLocalQuery] = useState(query);

  const performSearch = async (searchStr: string) => {
    if (!searchStr) return;
    setLoading(true);
    try {
      const res = await fetchEverything(searchStr, 1);
      setArticles(res.articles);
    } catch (err) {
      console.error(err);
      setArticles([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (query) {
      setLocalQuery(query);
      performSearch(query);
    }
  }, [query]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (localQuery.trim()) {
      setSearchParams({ q: localQuery.trim() });
    }
  };

  return (
    <div className="max-w-[1200px] mx-auto px-4 py-12 min-h-screen">
      <Helmet>
        <title>Search Results: {query} | PakPulse</title>
      </Helmet>

      <form onSubmit={handleSearch} className="relative max-w-3xl mx-auto mb-16">
        <SearchIcon className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-400 w-8 h-8" />
        <input 
          type="text" 
          value={localQuery}
          onChange={(e) => setLocalQuery(e.target.value)}
          placeholder="Search news, topics, or trends..." 
          className="w-full pl-20 pr-6 py-6 rounded-2xl border-2 border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-gray-900 dark:text-white text-xl font-medium focus:outline-none focus:border-brand-blue dark:focus:border-brand-blue shadow-lg transition-colors"
        />
        <button type="submit" className="absolute right-4 top-1/2 -translate-y-1/2 bg-brand-blue hover:bg-brand-blue-light text-white px-8 py-4 rounded-xl font-bold uppercase tracking-wider transition-colors shadow-md text-sm">
          Search
        </button>
      </form>

      <div className="mb-8">
         <h1 className="text-2xl font-bold text-gray-800 dark:text-gray-200">
           {loading ? 'Searching...' : `Search Results for "${query}"`}
         </h1>
         <p className="text-gray-500 dark:text-gray-400 mt-2">
            {!loading && `${articles.length} news articles found.`}
         </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
        {loading ? (
          Array(6).fill(0).map((_, i) => <NewsCardSkeleton key={i} />)
        ) : articles.length > 0 ? (
          articles.map((article, index) => (
            <NewsCard key={index} article={article} />
          ))
        ) : !loading && query ? (
          <div className="col-span-full py-20 bg-white dark:bg-slate-900 rounded-2xl border border-gray-100 dark:border-slate-800 text-center flex flex-col items-center shadow-sm">
             <div className="w-20 h-20 bg-gray-100 dark:bg-slate-800 rounded-full flex items-center justify-center mb-4">
                <SearchIcon className="w-10 h-10 text-gray-400" />
             </div>
             <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-2">No results found</h2>
             <p className="text-gray-500 max-w-md mx-auto">We couldn't find any news articles matching "{query}". Try using different keywords or check spelling.</p>
          </div>
        ) : null}
      </div>
    </div>
  );
}
