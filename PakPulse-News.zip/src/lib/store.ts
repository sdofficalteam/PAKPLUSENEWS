import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface Article {
  title: string;
  description: string;
  url: string;
  urlToImage: string;
  publishedAt: string;
  source: { name: string };
  author: string;
  content: string;
}

interface AppState {
  isDarkMode: boolean;
  toggleDarkMode: () => void;
  savedArticles: Article[];
  saveArticle: (article: Article) => void;
  removeArticle: (url: string) => void;
  isArticleSaved: (url: string) => boolean;
}

export const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      isDarkMode: false,
      toggleDarkMode: () => set((state) => ({ isDarkMode: !state.isDarkMode })),
      savedArticles: [],
      saveArticle: (article) => set((state) => ({
        savedArticles: [...state.savedArticles.filter(a => a.url !== article.url), article]
      })),
      removeArticle: (url) => set((state) => ({
        savedArticles: state.savedArticles.filter(a => a.url !== url)
      })),
      isArticleSaved: (url) => get().savedArticles.some(a => a.url === url)
    }),
    {
      name: 'pakpulse-storage',
    }
  )
);
