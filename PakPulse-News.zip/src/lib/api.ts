import { Article } from './store';

export type { Article };

const API_BASE = '/api/news';

export interface NewsResponse {
  status: string;
  totalResults: number;
  articles: Article[];
}

export const fetchTopHeadlines = async (category?: string, country: string = 'us', page: number = 1): Promise<NewsResponse> => {
  const params = new URLSearchParams({
    country,
    page: page.toString(),
    pageSize: '10'
  });
  if (category && category !== 'latest' && category !== 'world' && category !== 'pakistan') {
    params.set('category', category);
  }
  
  // Custom queries to simulate categories that aren't strictly NewsAPI categories
  if (category === 'pakistan' || country === 'pk') {
      params.delete('country');
      return fetchEverything('Pakistan', page);
  }
  if (category === 'world') {
      params.delete('country');
      return fetchEverything('World News', page);
  }

  const res = await fetch(`${API_BASE}/top-headlines?${params.toString()}`);
  if (!res.ok) throw new Error('Failed to fetch to headlines');
  return res.json();
};

export const fetchEverything = async (query: string, page: number = 1): Promise<NewsResponse> => {
  const params = new URLSearchParams({
    q: query,
    page: page.toString(),
    pageSize: '10',
    sortBy: 'publishedAt'
  });
  const res = await fetch(`${API_BASE}/everything?${params.toString()}`);
  if (!res.ok) throw new Error('Failed to fetch news');
  return res.json();
};
