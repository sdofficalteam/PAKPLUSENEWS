export const NAV_LINKS = [
  { name: 'Latest News', path: '/category/latest' },
  { name: 'Pakistan', path: '/category/pakistan' },
  { name: 'World', path: '/category/world' },
  { name: 'Business', path: '/category/business' },
  { name: 'Technology', path: '/category/technology' },
  { name: 'Sports', path: '/category/sports' },
  { name: 'Entertainment', path: '/category/entertainment' },
];

export const LEGAL_LINKS = [
  { name: 'About Us', path: '/about' },
  { name: 'Contact Us', path: '/contact' },
  { name: 'Privacy Policy', path: '/privacy' },
  { name: 'Terms & Conditions', path: '/terms' },
  { name: 'Disclaimer', path: '/disclaimer' },
  { name: 'Cookie Policy', path: '/cookie-policy' },
  { name: 'DMCA Policy', path: '/dmca' },
  { name: 'Editorial Policy', path: '/editorial-policy' },
  { name: 'Corrections Policy', path: '/corrections' },
  { name: 'Fact Checking', path: '/fact-checking' },
];
