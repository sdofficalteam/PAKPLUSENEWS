import { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import Category from './pages/Category';
import Legal from './pages/Legal';
import Search from './pages/Search';
import Bookmarks from './pages/Bookmarks';
import LiveTV from './pages/LiveTV';
import NotificationPopup from './components/NotificationPopup';
import { useStore } from './lib/store';

export default function App() {
  const isDarkMode = useStore((state) => state.isDarkMode);

  useEffect(() => {
    if (isDarkMode) {
      document.body.classList.add('dark');
    } else {
      document.body.classList.remove('dark');
    }
  }, [isDarkMode]);

  return (
    <>
      <NotificationPopup />
      <Router>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<Home />} />
            <Route path="category/:id" element={<Category />} />
            <Route path="search" element={<Search />} />
            <Route path="bookmarks" element={<Bookmarks />} />
            <Route path="live-tv" element={<LiveTV />} />
            
            <Route path="about" element={<Legal page="about" />} />
            <Route path="contact" element={<Legal page="contact" />} />
            <Route path="privacy" element={<Legal page="privacy" />} />
            <Route path="terms" element={<Legal page="terms" />} />
            <Route path="disclaimer" element={<Legal page="disclaimer" />} />
            <Route path="cookie-policy" element={<Legal page="cookie-policy" />} />
            <Route path="dmca" element={<Legal page="dmca" />} />
            <Route path="editorial-policy" element={<Legal page="editorial-policy" />} />
            <Route path="corrections" element={<Legal page="corrections" />} />
            <Route path="fact-checking" element={<Legal page="fact-checking" />} />
          </Route>
        </Routes>
      </Router>
    </>
  );
}

