import { Link } from 'react-router-dom';
import { Mail } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-brand-blue text-white py-4 md:h-12 flex flex-col md:flex-row items-center justify-between px-4 md:px-6 text-[10px] uppercase font-bold shrink-0 tracking-widest gap-4 md:gap-0 mt-auto">
      <div className="flex flex-wrap justify-center md:justify-start gap-4">
        <span>&copy; {new Date().getFullYear()} PakPulse News Network</span>
        <span className="hidden md:inline">•</span>
        <Link to="/privacy" className="hover:text-brand-red transition-colors">Privacy Policy</Link>
        <Link to="/terms" className="hover:text-brand-red transition-colors">Terms of Service</Link>
        <Link to="/editorial-policy" className="hover:text-brand-red transition-colors">Editorial Policy</Link>
      </div>
      <div className="flex items-center gap-4">
        <span>Connect:</span>
        <a href="mailto:sdofficalteam@gmail.com" className="bg-brand-red text-white border border-brand-red px-3 py-1.5 rounded hover:bg-white hover:text-brand-red transition-colors flex items-center gap-1.5">
          <Mail className="w-3.5 h-3.5" />
          sdofficalteam@gmail.com
        </a>
      </div>
    </footer>
  );
}
