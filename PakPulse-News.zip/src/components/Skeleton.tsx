import React from 'react';
import { clsx } from 'clsx';

export default function Skeleton({ className }: { className?: string, key?: React.Key | string | number }) {
  return (
    <div className={clsx("animate-pulse bg-gray-200 dark:bg-slate-700/50 rounded-md", className)} />
  );
}

export function NewsCardSkeleton({ featured, className }: { featured?: boolean, className?: string, key?: React.Key | string | number }) {
  return (
    <div className={clsx("flex flex-col bg-white dark:bg-slate-800/20 rounded-2xl overflow-hidden border border-gray-100 dark:border-slate-800", featured ? "md:flex-row col-span-1 md:col-span-2 lg:col-span-3 min-h-[400px]" : "h-full", className)}>
       <Skeleton className={clsx("w-full", featured ? "md:w-[60%] h-64 md:h-auto rounded-none" : "h-48 rounded-none")} />
       <div className={clsx("p-5 flex-1 flex flex-col gap-4", featured ? "md:w-[40%] justify-center" : "")}>
          <Skeleton className="w-1/4 h-4" />
          <div className="space-y-2">
             <Skeleton className="w-full h-6" />
             <Skeleton className="w-5/6 h-6" />
             {featured && <Skeleton className="w-4/6 h-6" />}
          </div>
          <div className="space-y-2 flex-1 mt-2">
             <Skeleton className="w-full h-3" />
             <Skeleton className="w-full h-3" />
             <Skeleton className="w-2/3 h-3" />
          </div>
          <div className="flex justify-between mt-auto">
             <Skeleton className="w-24 h-4" />
             <Skeleton className="w-6 h-6 rounded-full" />
          </div>
       </div>
    </div>
  );
}
