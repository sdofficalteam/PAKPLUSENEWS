import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import { Menu, X, Search as SearchIcon, Sun, Moon, Bookmark, Newspaper } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { NAV_LINKS } from '../lib/constants';
import { useStore } from '../lib/store';
import Ticker from './Ticker';

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const location = useLocation();
  const navigate = useNavigate();
  const { isDarkMode, toggleDarkMode, savedArticles } = useStore();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setMobileMenuOpen(false);
    setSearchOpen(false);
  }, [location]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
      setSearchOpen(false);
      setSearchQuery('');
    }
  };

  const todayDate = format(new Date(), 'EEEE, MMMM do, yyyy');

  return (
    <div className="sticky top-0 z-50 w-full flex flex-col relative shadow-sm">
      <header className="bg-white dark:bg-slate-900 border-b border-gray-200 dark:border-slate-800 h-16 w-full flex items-center px-4 md:px-6 shrink-0 justify-between">
          
          {/* Logo & Date */}
          <div className="flex items-center gap-2 md:gap-4 shrink-0">
            <Link to="/" className="text-xl md:text-2xl font-black uppercase tracking-tighter flex items-center">
              <span className="bg-brand-red text-white px-2 py-1 flex items-center gap-1">
                <Newspaper className="w-4 h-4 md:w-5 md:h-5 hidden sm:block" /> PAK
              </span>
              <span className="text-brand-blue dark:text-white ml-1">PULSE</span>
            </Link>
            <div className="hidden md:block h-8 w-px bg-gray-300 dark:bg-slate-700 mx-2"></div>
            <div className="hidden md:block text-[10px] md:text-xs font-bold text-gray-500 dark:text-gray-400 uppercase leading-tight">
              {format(new Date(), 'EEEE')}<br/>{format(new Date(), 'MMM dd, yyyy')}
            </div>
          </div>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex gap-4 lg:gap-6 text-sm font-bold uppercase tracking-wide overflow-hidden whitespace-nowrap">
            {NAV_LINKS.slice(0, 5).map((link) => (
              <Link
                key={link.name}
                to={link.path}
                className={`transition-colors ${
                  location.pathname === link.path 
                    ? 'text-brand-red' 
                    : 'text-brand-blue dark:text-gray-200 hover:text-brand-red'
                }`}
              >
                {link.name}
              </Link>
            ))}
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-2 sm:gap-4 ml-auto shrink-0 flex-nowrap">
            <div className="hidden lg:block relative">
              <input 
                type="text" 
                value={searchQuery}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleSearch(e as unknown as React.FormEvent);
                }}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search..." 
                className="bg-gray-100 dark:bg-slate-800 rounded-full px-4 py-1.5 text-sm border-none focus:ring-1 focus:ring-brand-red w-32 lg:w-48 text-gray-900 dark:text-white transition-all"
              />
              <SearchIcon className="w-4 h-4 absolute right-3 top-[7px] text-gray-400 cursor-pointer" onClick={handleSearch} />
            </div>
            
            <button onClick={() => setSearchOpen(!searchOpen)} className="lg:hidden text-gray-500 hover:text-brand-red p-1 shrink-0">
              <SearchIcon className="w-5 h-5" />
            </button>
            
            <Link to="/bookmarks" className="hidden sm:flex text-gray-500 hover:text-brand-red p-1 shrink-0">
               <Bookmark className="w-5 h-5" />
            </Link>

            <button 
              onClick={toggleDarkMode} 
              className="text-gray-500 hover:text-brand-red p-1 shrink-0"
            >
              {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>

            <Link to="/live-tv" className="bg-brand-red text-white px-2 sm:px-3 py-1.5 rounded text-[10px] sm:text-xs font-bold uppercase hover:opacity-90 flex items-center justify-center whitespace-nowrap shrink-0">
              Live TV
            </Link>
            
            {/* Mobile Menu Toggle */}
            <button 
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-1 text-brand-blue dark:text-white shrink-0"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </header>

        <Ticker />

      {/* Search Bar Overlay */}
      <AnimatePresence>
        {searchOpen && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="border-t border-gray-100 dark:border-slate-800 bg-gray-50 lg:bg-white dark:bg-slate-900 overflow-hidden absolute w-full top-[100%] left-0 z-40"
          >
            <div className="max-w-4xl mx-auto px-4 py-4 md:py-6">
              <form onSubmit={handleSearch} className="relative flex items-center">
                <SearchIcon className="w-6 h-6 absolute left-4 text-gray-400" />
                <input 
                  type="text" 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search for breaking news, topics, or authors..." 
                  className="w-full pl-14 pr-4 py-4 rounded-xl border border-gray-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-red/50 focus:border-brand-red text-lg shadow-inner"
                  autoFocus
                />
                <button type="submit" className="absolute right-4 px-4 py-2 bg-brand-blue text-white rounded-lg font-medium text-sm hover:bg-brand-blue-light transition-colors">
                  Search
                </button>
              </form>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="lg:hidden absolute top-[100%] left-0 w-full bg-white dark:bg-slate-900 border-b border-gray-200 dark:border-slate-800 shadow-xl overflow-y-auto max-h-[calc(100vh-100px)] flex flex-col z-30"
          >
            <div className="px-4 py-2 text-xs font-semibold text-gray-400 uppercase tracking-widest border-b border-gray-100 dark:border-slate-800">
               Categories
            </div>
            <nav className="flex flex-col py-2">
              {NAV_LINKS.map((link) => (
                <Link
                  key={link.name}
                  to={link.path}
                  className={`px-6 py-3.5 text-base font-bold uppercase tracking-wider border-b border-gray-50 dark:border-slate-800 ${
                    location.pathname === link.path 
                      ? 'text-brand-red' 
                      : 'text-brand-blue dark:text-gray-200'
                  }`}
                >
                  {link.name}
                </Link>
              ))}
            </nav>
            <div className="p-6">
              <Link to="/live-tv" className="block w-full py-3 mb-3 bg-brand-red text-white text-center font-bold rounded-lg uppercase tracking-wider text-sm shadow-md">
                Live TV Channels
              </Link>
              <button className="w-full py-3 bg-brand-blue dark:bg-slate-800 text-white font-bold rounded-lg uppercase tracking-wider text-sm shadow-md">
                Subscribe to Newsletter
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
