import React from 'react';
import { format } from 'date-fns';
import { Bookmark, BookmarkCheck, ExternalLink, Share2, Clock } from 'lucide-react';
import { Article, useStore } from '../lib/store';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';

interface NewsCardProps {
  article: Article;
  featured?: boolean;
  compact?: boolean;
  key?: React.Key | string | number;
}

export default function NewsCard({ article, featured = false, compact = false }: NewsCardProps) {
  const { isArticleSaved, saveArticle, removeArticle } = useStore();
  const isSaved = isArticleSaved(article.url);

  const fallbackImage = 'https://images.unsplash.com/photo-1585829365295-ab7cd400c167?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80';

  const handleBookmark = (e: React.MouseEvent) => {
    e.preventDefault();
    if (isSaved) {
      removeArticle(article.url);
    } else {
      saveArticle(article);
    }
  };

  const handleShare = (e: React.MouseEvent) => {
    e.preventDefault();
    if (navigator.share) {
      navigator.share({
        title: article.title,
        text: article.description,
        url: article.url,
      }).catch(console.error);
    } else {
      navigator.clipboard.writeText(article.url);
      alert('Link copied to clipboard!');
    }
  };

  const formattedDate = article.publishedAt 
    ? format(new Date(article.publishedAt), 'MMM dd, yyyy')
    : 'Recent';

  if (compact) {
    return (
      <motion.a 
        href={article.url}
        target="_blank"
        rel="noopener noreferrer"
        className="group flex gap-4 p-3 rounded-xl hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="w-24 h-24 shrink-0 rounded-lg overflow-hidden bg-gray-200 dark:bg-slate-700 relative">
          <img 
            src={article.urlToImage || fallbackImage} 
            alt={article.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            onError={(e) => { (e.target as HTMLImageElement).src = fallbackImage; }}
          />
        </div>
        <div className="flex flex-col justify-between py-1 flex-1">
          <h3 className="text-sm font-semibold text-gray-900 dark:text-gray-100 line-clamp-2 leading-snug group-hover:text-brand-red transition-colors">
            {article.title}
          </h3>
          <div className="flex items-center text-xs text-brand-blue-light dark:text-gray-400 gap-2 mt-2">
             <Clock className="w-3 h-3" />
             <span>{formattedDate}</span>
             <span className="hidden sm:inline px-1.5 py-0.5 rounded bg-gray-100 dark:bg-slate-700 text-[10px]">
                {article.source.name}
             </span>
          </div>
        </div>
      </motion.a>
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      className={cn(
        "group relative flex flex-col bg-white dark:bg-slate-900 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow",
        featured ? "md:col-span-2 lg:col-span-3 min-h-[400px]" : "h-full justify-between border border-gray-100 dark:border-slate-800 border-l-4 border-l-brand-red"
      )}
    >
      {featured ? (
        <div className="absolute inset-0 w-full h-full">
          <img 
            src={article.urlToImage || fallbackImage} 
            alt={article.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            onError={(e) => { (e.target as HTMLImageElement).src = fallbackImage; }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent opacity-90"></div>
        </div>
      ) : (
        <div className="relative overflow-hidden bg-gray-200 dark:bg-slate-800 aspect-[4/3] w-full shrink-0">
          <a href={article.url} target="_blank" rel="noopener noreferrer" className="block w-full h-full">
            <img 
              src={article.urlToImage || fallbackImage} 
              alt={article.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              onError={(e) => { (e.target as HTMLImageElement).src = fallbackImage; }}
            />
          </a>
        </div>
      )}

      {/* Badges */}
      {featured ? (
        <div className="absolute top-4 left-4 flex gap-2 z-10">
          <span className="bg-brand-red text-white text-[10px] font-black uppercase px-2 py-0.5 rounded shadow-sm">
            {article.source.name}
          </span>
        </div>
      ) : (
        <div className="absolute top-3 left-3 bg-brand-red text-white text-[10px] font-black px-2 py-0.5 rounded uppercase tracking-wider shadow-sm">
          {article.source.name}
        </div>
      )}
      
      <div className="absolute top-3 right-3 flex gap-2 z-10">
        <button 
          onClick={handleBookmark}
          aria-label="Bookmark"
          className={cn(
            "p-2 rounded-full transition-colors shadow-sm",
            featured ? "bg-white/20 backdrop-blur text-white hover:bg-brand-red" : "bg-white/90 dark:bg-slate-900/90 backdrop-blur-sm text-brand-blue hover:text-brand-red"
          )}
        >
          {isSaved ? <BookmarkCheck className="w-4 h-4 fill-current" /> : <Bookmark className="w-4 h-4" />}
        </button>
      </div>

      <div className={cn(
        "flex flex-col flex-1 relative z-10",
        featured ? "p-8 justify-end" : "p-4"
      )}>
        <a href={article.url} target="_blank" rel="noopener noreferrer" className="block w-full flex-1 group-hover:opacity-90">
          <h2 className={cn(
            "font-bold leading-tight transition-colors",
            featured ? "text-3xl md:text-4xl text-white mb-4 group-hover:underline" : "text-sm text-gray-900 dark:text-white mt-1 line-clamp-3"
          )}>
            {article.title}
          </h2>
          
          <p className={cn(
            "text-sans",
            featured ? "text-white/80 text-base md:text-lg line-clamp-3 md:line-clamp-4 mb-4" : "text-[11px] text-gray-500 dark:text-gray-400 line-clamp-2 mt-2"
          )}>
            {article.description || "Click to read the full story on the original source."}
          </p>
        </a>

        <div className={cn(
            "flex items-center gap-4 mt-auto",
            featured ? "text-white/70 text-xs border-t border-white/10 pt-4" : "text-xs text-gray-400 pt-4 border-t border-gray-100 dark:border-slate-800"
        )}>
          <div className="flex items-center gap-1.5 font-bold">
            <Clock className="w-3.5 h-3.5" />
            <time>{formattedDate}</time>
          </div>
          <button 
            onClick={handleShare}
            aria-label="Share article"
            className="ml-auto hover:text-brand-red transition-colors"
          >
            <Share2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </motion.div>
  );
}
