import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X } from 'lucide-react';

export default function NotificationPopup() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Show initially after a short delay
    const initialTimer = setTimeout(() => {
      setIsVisible(true);
    }, 2000);

    return () => clearTimeout(initialTimer);
  }, []);

  useEffect(() => {
    let hideTimer: NodeJS.Timeout;
    
    if (isVisible) {
      // Auto-hide after 8 seconds
      hideTimer = setTimeout(() => {
        setIsVisible(false);
      }, 8000);
    } else {
      // Re-appear after 60 seconds (1 minute)
      hideTimer = setTimeout(() => {
        setIsVisible(true);
      }, 60000);
    }

    return () => clearTimeout(hideTimer);
  }, [isVisible]);

  const handleClose = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsVisible(false);
  };

  const handleCardClick = () => {
    window.open('https://digitaluqaab.agency', '_blank');
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
           initial={{ opacity: 0, x: -50 }}
           animate={{ opacity: 1, x: 0 }}
           exit={{ opacity: 0, x: -50 }}
           transition={{ duration: 0.5, ease: "easeOut" }}
           className="fixed top-20 left-4 z-[60] w-[260px] sm:w-[300px] cursor-pointer shadow-2xl group"
           onClick={handleCardClick}
        >
           {/* Glow Effect */}
           <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-600 rounded-2xl blur-md opacity-30 group-hover:opacity-70 transition-opacity duration-500"></div>
           
           {/* Glassmorphism Card */}
           <div className="relative bg-white/80 dark:bg-slate-900/90 backdrop-blur-xl border border-white/40 dark:border-slate-700/50 p-4 rounded-2xl shadow-[0_8px_30px_rgb(0,0,0,0.12)] overflow-hidden">
             
             {/* Close Button */}
             <button 
               onClick={handleClose}
               className="absolute top-2 right-2 text-gray-400 hover:text-gray-600 dark:hover:text-white bg-white/50 dark:bg-black/20 hover:bg-black/5 dark:hover:bg-white/10 rounded-full p-1 backdrop-blur-sm transition-colors z-10"
             >
               <X className="w-4 h-4" />
             </button>

             <div className="flex flex-col gap-2 relative z-0 pr-4">
                <h4 className="text-sm sm:text-base font-black text-brand-blue dark:text-white tracking-tight flex items-center gap-1.5 leading-tight">
                  <span className="text-lg">🚀</span> Visit Our Agency
                </h4>
                <p className="text-[11px] sm:text-xs text-gray-700 dark:text-gray-300 font-medium leading-normal mb-1">
                  Build Your Professional Website with Digital Uqaab
                </p>
                
                <div className="mt-1">
                  <span className="inline-flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-white bg-gradient-to-r from-brand-blue to-purple-600 dark:from-indigo-600 dark:to-purple-600 px-3 py-1.5 rounded shadow-sm group-hover:shadow-md group-hover:scale-[1.02] transition-all">
                    ✨ Visit Now
                  </span>
                </div>
             </div>
           </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
