import React, { useState, useEffect } from 'react';
import { fetchTopHeadlines } from '../lib/api';
import type { Article } from '../lib/store';

export default function Ticker() {
  const [headlines, setHeadlines] = useState<Article[]>([]);

  useEffect(() => {
    fetchTopHeadlines('latest', 'us')
      .then(res => setHeadlines(res.articles.slice(0, 10)))
      .catch(console.error);
  }, []);

  if (headlines.length === 0) return null;

  return (
    <div className="bg-brand-red text-white h-8 overflow-hidden flex items-center shrink-0 w-full relative z-10 border-b border-brand-red-dark">
      <div className="bg-black px-4 h-full flex items-center text-xs font-black italic uppercase shrink-0 z-10">
        Breaking
      </div>
      <div className="flex-1 overflow-hidden h-full flex items-center">
        <div className="ticker-anim text-sm font-medium">
          {headlines.map((item, index) => (
             <span key={index} className="inline-block mx-4">
               • <a href={item.url} target="_blank" rel="noopener noreferrer" className="mx-2 hover:underline hover:text-white/80 transition-colors">{item.title}</a>
             </span>
          ))}
          <span className="inline-block mx-4">•</span>
        </div>
      </div>
    </div>
  );
}
