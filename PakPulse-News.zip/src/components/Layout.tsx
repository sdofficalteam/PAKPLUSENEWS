import { Outlet } from 'react-router-dom';
import Header from './Header';
import Footer from './Footer';
import { Helmet } from 'react-helmet-async';

export default function Layout() {
  return (
    <div className="min-h-screen flex flex-col font-sans selection:bg-brand-red/20 selection:text-brand-red">
      <Helmet>
        <title>PakPulse News | Live Breaking News & Updates</title>
        <meta name="description" content="A premium and modern news portal featuring the latest updates from Pakistan, World, Business, and Technology." />
      </Helmet>
      
      <Header />
      
      <main className="flex-1 w-full bg-brand-gray dark:bg-[#0f172a] transition-colors duration-200">
        <Outlet />
      </main>
      
      <Footer />
    </div>
  );
}
